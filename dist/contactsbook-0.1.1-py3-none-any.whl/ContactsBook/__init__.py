# from src.CoreProject.func import compiling_page, add, change, remove, phone, show, show_all, birthday, delete, get_handler, phonebook
# from src.CoreProject.classes import Record, AddressBook
# from src.CoreProject.sorted_files import sorted_files
# from src.CoreProject.my_calendar_frame import MyCalendar
